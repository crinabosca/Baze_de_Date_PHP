<html>
 <head>
  <title>Rezultat ex4b</title>
  <style>
   table, th, td
   {
     border: 1px solid black;
   }
  </style>
 </head>
<body>
 <h3>Rezultat</h3>
<?php

$user = 'root';
$pass = '';
$host = 'localhost';
$db_name = 'proiectcrina';

$connect = mysqli_connect($host, $user, $pass, $db_name);
// se verifică dacă a funcţionat conectarea
if ($connect->connect_error)
{
  die('Eroare la conectare: ' . $connect->connect_error);
}
// se emite interogarea
$query = "SELECT a1.id_ap AS id_ap1, a2.id_ap AS id_ap2
FROM apartament a1 INNER JOIN apartament a2 ON (a1.id_proprietar = a2.id_proprietar)
WHERE a1.adresa = a2.adresa AND a1.id_ap < a2.id_ap;	
";

$result = mysqli_query($connect, $query);
// verifică dacă rezultatul este în regulă
if (!$result)
{
  die('Interogare gresita: ' . mysqli_error());
}
// se obţine numărul tuplelor returnate
$num_results = mysqli_num_rows($result);
if($num_results==0)
{
    echo 'Nu au fost gasite '.$litera.'!';
    exit;
}
// se afişează fiecare tuplă returnată
echo '<table style="width:70%">
  <tr>
	<th>id_ap1</th>
	<th>id_ap2</th>
  </tr>';
for ($i = 0; $i < $num_results; $i++)
{
  $row = mysqli_fetch_assoc($result);
  
	 echo '<tr><td>'.stripslashes($row['id_ap1']).'</td>';
	 //echo '<td>'.htmlspecialchars(stripslashes($row['numele'])).'</td>';
	  echo '<td>'.stripslashes($row['id_ap2']).'</td></tr>';
  
}
echo '</table>';
// deconectarea de la BD
mysqli_close($connect);
?>
</body>
</html>
