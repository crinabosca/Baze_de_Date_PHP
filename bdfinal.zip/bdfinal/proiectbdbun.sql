 
CREATE TABLE Proprietar 
( id_proprietar int,
nume VARCHAR (25) ,
email VARCHAR (30) );



CREATE TABLE Apartament 
(id_ap int,	
adresa VARCHAR (50),
nr_ap int ,
suprafata int,
id_proprietar int);




CREATE TABLE Consum 
(id_ap  int,
an int,
luna int,
nr_pers int,
cantitate int,
valoare int,
pret_apa int);


CREATE TABLE Chitanta
(nr int,
data DATE,
id_ap int,
valoare float );


ALTER TABLE Proprietar 
 ADD CONSTRAINT id_proprietar_pk PRIMARY KEY(id_proprietar);
 
 ALTER TABLE APARTAMENT 
ADD CONSTRAINT id_prop_fk FOREIGN KEY (id_proprietar) REFERENCES Proprietar (id_proprietar) ON DELETE CASCADE ;


ALTER TABLE APARTAMENT 
ADD CONSTRAINT id_ap_pk PRIMARY KEY(id_ap);

ALTER TABLE Consum 
ADD CONSTRAINT consum_pk PRIMARY KEY(id_ap, an, luna);


ALTER TABLE Consum 
ADD CONSTRAINT id_ap1_fk FOREIGN KEY(id_ap) REFERENCES Apartament(id_ap) ON DELETE CASCADE;
 
ALTER TABLE Chitanta
ADD CONSTRAINT id_ap_chitanta_fk FOREIGN KEY (id_ap) REFERENCES Apartament(id_ap);

ALTER TABLE Chitanta
ADD CONSTRAINT nr_chitanta_pk PRIMARY  KEY (nr);




ALTER TABLE Proprietar 
ADD telefon VARCHAR (11);




-- PROPRIETAR
insert into Proprietar(id_proprietar,nume,email,telefon)
values ('1','Crina', 'crinabosca17@yahoo.com','0752838456');
insert into Proprietar(id_proprietar,nume,email,telefon)
values ('2','Denisa', 'denisahiticas11@yahoo.com','0768987658');
insert into Proprietar(id_proprietar,nume,email,telefon)
values ('3','Valentin', 'vali_ierima@yahoo.com','0768906578');
insert into Proprietar(id_proprietar,nume,email,telefon)
values ('4','Gabriel', 'gabrielhojda17@yahoo.com','0756899034');
insert into Proprietar(id_proprietar,nume,email,telefon)
values ('11','Adrian', 'adrianirimes11@yahoo.com','0757898065');
insert into Proprietar(id_proprietar,nume,email,telefon)
values ('6','Alina', 'alinahiticas@yahoo.com','0756985426');
insert into Proprietar(id_proprietar,nume,email,telefon)
values ('7','Victoria', 'victoriaierima1@yahoo.com','0768409765');
insert into Proprietar(id_proprietar,nume,email,telefon)
values ('8','Andrei', 'andreibosca25@yahoo.com','0743860208');
insert into Proprietar(id_proprietar,nume,email,telefon)
values ('9','Anuta', 'anutabosca14@yahoo.com','0753454678');
insert into Proprietar(id_proprietar,nume,email,telefon)
values ('10','Vasile', 'vasilebosca34@yahoo.com','0789087456');
insert into Proprietar(id_proprietar,nume,email,telefon)
values ('5','Jhon Doe', 'jhondoe67@yahoo.com','0789765427');
insert into Proprietar(id_proprietar,nume,email,telefon)
values ('12','Carol', 'caroldanciuc17@yahoo.com','0789657898');
insert into Proprietar(id_proprietar,nume,email,telefon)
values ('13','Fabi', 'fabifabian3@yahoo.com','0756898790');
insert into Proprietar(id_proprietar,nume,email,telefon)
values ('14','Ancuta Liliana', 'ancutaliliana12@yahoo.com','0765789076');
-- APARTAMENT 
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('101', 'Cluj-Napoca Observator 1', '22', '23', '1');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('100', 'Cluj-Napoca Observator 1', '30', '33', '1');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('177', 'Cluj-Napoca Observator 1', '37', '45', '1');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('21', 'Cluj-Napoca Observator 1', '22', '45', '1');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('22', 'Cluj-Napoca Observator 1', '30', '55', '2');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('23', 'Cluj-Napoca Observator 1', '37', '34', '3');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('24', 'Cluj-Napoca Observator 26', '78', '33', '4');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('25', 'Cluj-Napoca Fantanele 1', '34', '56', '6');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('27', 'Cluj-Napoca Baritiu 1', '11', '57', '6');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('28', 'Cluj-Napoca Daicovici 23', '35', '56', '7');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('29', 'Cluj-Napoca Daicovici 24', '56', '36', '8');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('30', 'Cluj-Napoca Sub Cetate 23', '45', '35', '9');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('32', 'Cluj-Napoca Crizantemelor 12', '21', '63', '10');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('31', 'Cluj-Napoca Donath 34', '23', '34', '11');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('36', 'Cluj-Napoca Donath 1', '341', '32', '12');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('37', 'Cluj-Napoca Traian 36', '12', '37', '14');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('38', 'Cluj-Napoca Anton Pan 23', '1', '39', '14');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('389', 'Cluj-Napoca Anton Pan 83', '3', '59', '14');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('39', 'Cluj-Napoca Traian 38', '31', '100', '5');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('40', 'Cluj-Napoca Lalelelor 23', '11', '93', '5');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('41', 'Cluj-Napoca Tudor Cantimir 25', '451', '63', '10');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('42', 'Cluj-Napoca Alexandru Avhuta 23', '8', '73', '9');
insert into Apartament(id_ap, adresa, nr_ap, suprafata,id_proprietar) values ('5', 'Cluj-Napoca Alexandru Alut 28', '6', '70', '8');
-- CONSUM 

insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values(21,2022,10,2,25,80,190);
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('21','2022','9','4', '48 ','99','125');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('32','2022','7','2', '45 ','69','345');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('5','2021','3','10', '89 ','70','800');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('5','2020','7','10', '65 ','37','32');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('5','2019','9','10', '15 ','27','329');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('5','2022','10','10', '75 ','39','125');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('22','2022','10','3','45','87','128');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('23','2022','10','4','49','85','100');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('24','2021','3','2','50','90','123');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('25','2021','3','2','53','354','128');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('27','2013','2','6','76','87','230');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('28','2013','4','3','95','56','120');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('29','2014','5','2','45','99','230');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('30','2016','6','2','89','29','670');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('22','2022','3','48','45','97','230');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('37','2022','3','0','0','67','230');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('21','2022','3','78','44','77','20');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('31','2019','7','9','80','67','87');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('32','2017','9','7','87','76','267');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('31','2022','9','0','0','87','230');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('36','2002','11','0','0','59','140');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('37','2012','1','2','65','76','120');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('38','2013','12','3','87','45','230');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('39','2014','2','4','33','85','300');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('41','2019','7','3','38','90','980');
insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('40','2017','9','4','34','91','230');

-- CHITANTA
 
insert into Chitanta(nr, data, id_ap, valoare) values('1','01-Oct-2022','21','70');
insert into Chitanta(nr, data, id_ap, valoare) values('2','01-Oct-2022','22','700');
insert into Chitanta(nr, data, id_ap, valoare) values('3','12-Jan-2017','23','234');
insert into Chitanta(nr, data, id_ap, valoare) values('4','13-Jan-2020','24','345');
insert into Chitanta(nr, data, id_ap, valoare) values('5','02-Dec-2021','27','123');
insert into Chitanta(nr, data, id_ap, valoare) values('7','13-Feb-2022','28','234');
insert into Chitanta(nr, data, id_ap, valoare) values('8','14-Mar-2019','29','89');
insert into Chitanta(nr, data, id_ap, valoare) values('9','17-Apr-2021','30','90');
insert into Chitanta(nr, data, id_ap, valoare) values('10','21-Feb-2022','31','78');
insert into Chitanta(nr, data, id_ap, valoare) values('11','26-Jan-2018','32','90');
insert into Chitanta(nr, data, id_ap, valoare) values('12','06-Oct-2020','31','765');
insert into Chitanta(nr, data, id_ap, valoare) values('13','18-Jun-2017','36','567');
insert into Chitanta(nr, data, id_ap, valoare) values('14','20-Jul-2019','21','123');
insert into Chitanta(nr, data, id_ap, valoare) values('15','11-Jan-2022','36','456');
insert into Chitanta(nr, data, id_ap, valoare) values('16','29-Jun-2017','21','123');
insert into Chitanta(nr, data, id_ap, valoare) values('17','22-Jul-2018','22','343');
insert into Chitanta(nr, data, id_ap, valoare) values('18','19-Jan-2019','23','77');
insert into Chitanta(nr, data, id_ap, valoare) values('19','21-Jan-2020','21','97');


 -- 01.02
 
 
-- a) Coloana valoare trebuie să ia valori pozitive. 

ALTER TABLE Consum ADD CONSTRAINT conditie Check (valoare>0);

-- PENTRU VERIFICAT 

-- insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('38','2012','1','-2','-10','-1','120');

-- b) Dacă cantitate este 0 atunci nr_pers trebuie să fie 0.
ALTER TABLE Consum
ADD CONSTRAINT cantitate_nr_pers_consum_ck CHECK (nr_pers = CASE WHEN cantitate = 0 THEN 0 ELSE nr_pers END);
-- PENTRU VERIFICARE

-- insert into Consum(id_ap, an, luna, nr_pers, cantitate, valoare, pret_apa)  values('32','2022','4','1','0','67','230');
