<html>
 <head>
  <title>Rezultat ex5b</title>
  <style>
   table, th, td
   {
     border: 1px solid black;
   }
  </style>
 </head>
<body>
 <h3>Rezultat</h3>
<?php

$user = 'root';
$pass = '';
$host = 'localhost';
$db_name = 'proiectcrina';

$connect = mysqli_connect($host, $user, $pass, $db_name);
// se verifică dacă a funcţionat conectarea
if ($connect->connect_error)
{
  die('Eroare la conectare: ' . $connect->connect_error);
}
// se emite interogarea
$query = "Select p.nume AS numep
from Proprietar p JOIN apartament a ON (a.id_proprietar = p.id_proprietar) JOIN Consum c ON (a.id_ap = c.id_ap)
where an = 2022 AND luna = 3 AND valoare IN (SELECT valoare
from proprietar p JOIN apartament a ON (a.id_proprietar = p.id_proprietar) JOIN Consum c ON (a.id_ap = c.id_ap)
where an = 2022 AND luna = 3 AND nume = 'John Doe');

";

$result = mysqli_query($connect, $query);
// verifică dacă rezultatul este în regulă
if (!$result)
{
  die('Interogare gresita: ' . mysqli_error());
}
// se obţine numărul tuplelor returnate
$num_results = mysqli_num_rows($result);
if($num_results==0)
{
    echo 'Nu au fost gasite '.$litera.'!';
    exit;
}
// se afişează fiecare tuplă returnată
echo '<table style="width:70%">
  <tr>
	<th>numep</th>
  </tr>';
for ($i = 0; $i < $num_results; $i++)
{
  $row = mysqli_fetch_assoc($result);
  
	 echo '<tr><td>'.stripslashes($row['numep']).'</td></tr>';
  
}
echo '</table>';
// deconectarea de la BD
mysqli_close($connect);
?>
</body>
</html>