  <title>Rezultat ex3b</title>
  <style>
   table, th, td
   {
     border: 1px solid black;
   }
  </style>
 </head>
<body>
 <h3>Rezultat</h3>
<?php
$id_ap=$_POST['id_ap'];
$id_ap= trim($id_ap);
if(!$id_ap)
{
    echo 'Nu ati introdus nimic!';
    echo '<a href="subpunctulb3.html">Incercati din nou!';
    exit;
}
if (!($id_ap=5))
{
  echo 'Nu ati introdus';
  echo '<a href="subpunctulb3.html">Incercati din nou!';
  exit;
}
$user = 'root';
$pass = '';
$host = 'localhost';
$db_name = 'proiectcrina';

$connect = mysqli_connect($host, $user, $pass, $db_name);
// se verifică dacă a funcţionat conectarea
if ($connect->connect_error)
{
  die('Eroare la conectare: ' . $connect->connect_error);
}
// se emite interogarea
$query = "Select *
FROM Consum
WHERE id_ap=5  ORDER BY an DESC,luna DESC;
";

$result = mysqli_query($connect, $query);
// verifică dacă rezultatul este în regulă
if (!$result)
{
  die('Interogare gresita: ' . mysqli_error());
}
// se obţine numărul tuplelor returnate
$num_results = mysqli_num_rows($result);
if($num_results==0)
{
    echo 'Nu au fost gasite apartamente cu id_ap=5'.$litera.'!';
    exit;
}
// se afişează fiecare tuplă returnată
echo '<table style="width:40%">
  <tr>
    <th>an</th>
	<th>luna</th>
  </tr>';
for ($i = 0; $i < $num_results; $i++)
{
  $row = mysqli_fetch_assoc($result);
  
  echo '<tr><td>'.stripslashes($row['an']).'</td>';
  //echo '<td>'.htmlspecialchars(stripslashes($row['numele'])).'</td>';
  echo '<td>'.stripslashes($row['luna']).'</td></tr>';
  
}
echo '</table>';
// deconectarea de la BD
mysqli_close($connect);
?>
</body>
</html>