<html>
 <head>
  <title>Rezultat ex3a</title>
  <style>
   table, th, td
   {
     border: 1px solid black;
   }
  </style>
 </head>
<body>
 <h3>Rezultat</h3>
<?php
$litera=$_POST['litera'];
$suprafata=$_POST['suprafata'];
$litera= trim($litera); 
$suprafata= trim($suprafata);
if(!$litera)
{
    echo 'Nu ati introdus nimic!';
    echo '<a href="new1.html">Incercati din nou!';
    exit;
}
if (!($suprafata<50) && !($litera>='v'))
{
  echo 'Nu ati introdus o litera!';
  echo '<a href="new1.html">Incercati din nou!';
  exit;
}
$user = 'root';
$pass = '';
$host = 'localhost';
$db_name = 'proiectcrina';

$connect = mysqli_connect($host, $user, $pass, $db_name);
// se verifică dacă a funcţionat conectarea
if ($connect->connect_error)
{
  die('Eroare la conectare: ' . $connect->connect_error);
}
// se emite interogarea
$query = "Select * 
FROM Apartament
WHERE suprafata < 50 AND  adresa like '%v%' ORDER BY  suprafata";

$result = mysqli_query($connect, $query);
// verifică dacă rezultatul este în regulă
if (!$result)
{
  die('Interogare gresita: ' . mysqli_error());
}
// se obţine numărul tuplelor returnate
$num_results = mysqli_num_rows($result);
if($num_results==0)
{
    echo 'Nu au fost gasite apartamente cu suprafata<50 care sa contina litera v '.$litera.'!';
    exit;
}
// se afişează fiecare tuplă returnată
echo '<table style="width:40%">
  <tr>
    <th>Suprafata</th>
	<th>adresa</th>
  </tr>';
for ($i = 0; $i < $num_results; $i++)
{
  $row = mysqli_fetch_assoc($result);
  
  echo '<tr><td>'.stripslashes($row['suprafata']).'</td>';
  //echo '<td>'.htmlspecialchars(stripslashes($row['numele'])).'</td>';
  echo '<td>'.stripslashes($row['adresa']).'</td></tr>';
  
}
echo '</table>';
// deconectarea de la BD
mysqli_close($connect);
?>
</body>
</html>
