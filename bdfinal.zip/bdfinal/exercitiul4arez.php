<html>
 <head>
  <title>Rezultat ex4a</title>
  <style>
   table, th, td
   {
     border: 1px solid black;
   }
  </style>
 </head>
<body>
 <h3>Rezultat</h3>
<?php
$luna=$_POST['luna'];
$an=$_POST['an'];
$adresa=$_POST['adresa'];
$luna= trim($luna); 
$an= trim($an);
$adresa= trim($adresa);
if(!$adresa)
{
    echo 'Nu ati introdus nimic!';
    echo '<a href="subpunctula4.html">Incercati din nou!';
    exit;
}
if (!($luna=10) && !($adresa='Cluj-Napoca Observator 1') && !($luna=10))
{
  echo 'Nu ati introdus o adresa!';
  echo '<a href="subpunctula4.html">Incercati din nou!';
  exit;
}
$user = 'root';
$pass = '';
$host = 'localhost';
$db_name = 'proiectcrina';

$connect = mysqli_connect($host, $user, $pass, $db_name);
// se verifică dacă a funcţionat conectarea
if ($connect->connect_error)
{
  die('Eroare la conectare: ' . $connect->connect_error);
}
// se emite interogarea
$query = "SELECT Apartament.adresa AS adresa, Apartament.nr_ap AS nr_ap, Proprietar.nume AS nume, Consum.valoare AS valoare,
Consum.luna AS luna, Consum.an AS an, Apartament.adresa AS adresa
FROM Apartament NATURAL JOIN Proprietar NATURAL JOIN Consum
WHERE luna = '10' AND an = '2022' AND adresa = 'Cluj-Napoca Observator 1';
";

$result = mysqli_query($connect, $query);
// verifică dacă rezultatul este în regulă
if (!$result)
{
  die('Interogare gresita: ' . mysqli_error());
}
// se obţine numărul tuplelor returnate
$num_results = mysqli_num_rows($result);
if($num_results==0)
{
    echo 'Nu au fost gasite '.$litera.'!';
    exit;
}
// se afişează fiecare tuplă returnată
echo '<table style="width:70%">
  <tr>
	<th>valoare</th>
	<th>nume</th>
	<th>nr_ap</th>
	<th>adresa</th>
  </tr>';
for ($i = 0; $i < $num_results; $i++)
{
  $row = mysqli_fetch_assoc($result);
  
	 echo '<tr><td>'.stripslashes($row['valoare']).'</td>';
	 //echo '<td>'.htmlspecialchars(stripslashes($row['numele'])).'</td>';
	  echo '<td>'.stripslashes($row['nr_ap']).'</td>';
	   echo '<td>'.stripslashes($row['nume']).'</td>';
	   echo '<td>'.stripslashes($row['adresa']).'</td></tr>';
  
}
echo '</table>';
// deconectarea de la BD
mysqli_close($connect);
?>
</body>
</html>
